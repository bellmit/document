package java.lang;

public class String {
    static {
        System.out.println("我们自定义的string 加载了..");
    }

    public static void main(String[] args) {
        System.out.println("执行string的main");
    }
}
