package com.lagou.unit;

public class StackDemo2 {
    public static void main(String[] args) {
        int i = 1;
        int j = 2;
        int z = i + j;
    }
}
