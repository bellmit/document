package com.lagou.unit2;

/**
 * 查看加载rt.jar下的字节码文件
 * -XX:+TraceClassLoading
 */
public class Demo1_ClassLoader {
    public static void main(String[] args) {
        System.out.println("hello classLoader");
    }
}
