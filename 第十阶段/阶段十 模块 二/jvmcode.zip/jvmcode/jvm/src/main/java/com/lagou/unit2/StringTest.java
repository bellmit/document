package com.lagou.unit2;

public class StringTest {
    public static void main(String[] args) {
        String str = new String();
        System.out.println("stringtest...");
    }
}
