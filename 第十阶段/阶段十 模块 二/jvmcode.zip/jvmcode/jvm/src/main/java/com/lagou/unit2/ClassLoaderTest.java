package com.lagou.unit2;

public class ClassLoaderTest {
    public static void main(String[] args) {
        //创建自定义类加载器
        MyClassLoader classLoader = new MyClassLoader("d:/");
        try {
            Class<?> clazz = classLoader.loadClass("TestMain");
            System.out.println("我是由"+clazz.getClassLoader().getClass().getName()+"类加载器加载的.");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
