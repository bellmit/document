package com.lagou.unit;

public class HelloWorld {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("Hello World");
    }
}