package com.lagou.service;

public interface HelloService {
    String  sayHello(String name);
}
